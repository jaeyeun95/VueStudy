<template>
	<div>Page is not found</div>
</template>

<script>
export default {};
</script>

<style></style>
