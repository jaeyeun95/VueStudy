package com.example.demo.enums;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}