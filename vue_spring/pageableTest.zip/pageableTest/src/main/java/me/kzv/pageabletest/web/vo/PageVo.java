package me.kzv.pageabletest.web.vo;

import lombok.Data;

@Data
public class PageVo {
    private int pageNumber;
    private int pageSize;
    private Long offeSet;
}
