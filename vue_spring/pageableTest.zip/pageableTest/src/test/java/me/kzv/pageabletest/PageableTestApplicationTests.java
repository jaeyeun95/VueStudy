package me.kzv.pageabletest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PageableTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
